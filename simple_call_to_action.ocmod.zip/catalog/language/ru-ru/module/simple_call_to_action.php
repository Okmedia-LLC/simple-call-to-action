<?php 

// text
$_['text_button'] = "Отправить запрос";